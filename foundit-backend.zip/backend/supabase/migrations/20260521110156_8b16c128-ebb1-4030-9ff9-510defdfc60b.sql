
-- Restrict public listing: only authenticated users can read item photos
DROP POLICY "Item photos public read" ON storage.objects;
CREATE POLICY "Item photos authenticated read" ON storage.objects
  FOR SELECT TO authenticated USING (bucket_id = 'item-photos');

UPDATE storage.buckets SET public = false WHERE id = 'item-photos';

-- Lock down SECURITY DEFINER functions from being called directly via PostgREST
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.validate_item() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.validate_profile() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.has_role(UUID, public.app_role) FROM PUBLIC, anon;
