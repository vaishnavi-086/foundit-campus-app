# FoundIt Backend

This package contains the secure application layer for FoundIt:

- Authenticated server functions for listing, creating, and deleting items.
- Server-side Zod validation for report forms.
- Bearer-token verification and user-scoped cloud access.
- Database migrations with RLS policies, role separation, profile protection, item validation triggers, and private photo storage policies.

## Setup

1. Copy `.env.example` to `.env`.
2. Set the server values, keeping the service-role key server-only.
3. Apply the SQL files in `supabase/migrations/` to your cloud database.
4. Use the backend files together with the FoundIt frontend package.

The `user_roles` table intentionally stays separate from profile data. Item browsing is authenticated, item creation is owner-scoped, and admin/moderator changes are enforced by database policies.
