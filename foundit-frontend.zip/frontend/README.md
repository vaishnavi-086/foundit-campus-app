# FoundIt Frontend

This package contains the complete FoundIt web application and its TanStack Start runtime bindings.
It includes the landing page, authentication screens, protected dashboard, report-item flow, responsive navigation, and browser-side cloud client.

## Setup

1. Copy `.env.example` to `.env`.
2. Add the public browser configuration values from your cloud project.
3. Install dependencies with `bun install` or `npm install`.
4. Start with `bun run dev` or `npm run dev`.

The separate `backend` package contains the server-side validation, authentication middleware, and database migrations.
Do not commit `.env` or any service-role key.
