import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ALLOWED_CATEGORIES = [
  "Electronics",
  "Accessories",
  "Books",
  "Personal",
  "Jewelry",
  "Clothing",
  "Other",
] as const;

const reportSchema = z.object({
  title: z.string().trim().min(2).max(120),
  description: z.string().trim().max(2000).optional().or(z.literal("")),
  category: z.enum(ALLOWED_CATEGORIES),
  location: z.string().trim().min(1).max(200),
  status: z.enum(["lost", "found"]),
  photo_url: z
    .string()
    .trim()
    .url()
    .max(1024)
    .optional()
    .or(z.literal("")),
});

export const listItems = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data, error } = await supabase
      .from("items")
      .select("id,title,description,category,location,status,photo_url,created_at,user_id")
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const createItem = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => reportSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { error, data: row } = await supabase
      .from("items")
      .insert({
        user_id: userId,
        title: data.title,
        description: data.description || null,
        category: data.category,
        location: data.location,
        status: data.status,
        photo_url: data.photo_url || null,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const deleteItem = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    // RLS enforces ownership/admin
    const { error } = await supabase.from("items").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });