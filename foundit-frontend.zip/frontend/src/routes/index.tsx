import { createFileRoute, Link } from "@tanstack/react-router";
import { Search, MapPin, Bell, ShieldCheck, Sparkles, ArrowRight, Camera, MessageSquare, CheckCircle2 } from "lucide-react";
import heroImg from "@/assets/campus-hero.jpg";

export const Route = createFileRoute("/")({
  component: Index,
});

function Nav() {
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        <a href="#" className="flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-primary text-primary-foreground">
            <Search className="h-4 w-4" strokeWidth={2.5} />
          </span>
          <span className="font-display text-lg font-semibold tracking-tight">FoundIt</span>
        </a>
        <nav className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
          <a href="#features" className="transition hover:text-foreground">Features</a>
          <a href="#how" className="transition hover:text-foreground">How it works</a>
          <a href="#campus" className="transition hover:text-foreground">For campuses</a>
          <a href="#faq" className="transition hover:text-foreground">FAQ</a>
        </nav>
        <div className="flex items-center gap-3">
          <button className="hidden text-sm font-medium text-foreground/80 hover:text-foreground sm:block">Sign in</button>
          <Link to="/dashboard" className="inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow-[var(--shadow-soft)] transition hover:opacity-95">
            Get started <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 -z-10 bg-[var(--gradient-soft)]" />
      <div className="absolute -top-32 left-1/2 -z-10 h-[500px] w-[800px] -translate-x-1/2 rounded-full bg-primary/10 blur-3xl" />
      <div className="mx-auto max-w-7xl px-6 pb-20 pt-16 md:pt-24">
        <div className="mx-auto max-w-3xl text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
            <Sparkles className="h-3.5 w-3.5 text-primary" /> AI-powered item matching
          </span>
          <h1 className="mt-6 text-5xl font-semibold leading-[1.05] tracking-tight md:text-6xl">
            Lose less. <span className="text-primary">Find more.</span>
            <br />The smart way for campuses.
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-lg text-muted-foreground">
            FoundIt reunites students with their belongings in minutes — not weeks.
            Smart matching, secure pickup, real-time alerts across your entire campus.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link to="/dashboard" className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground shadow-[var(--shadow-elegant)] transition hover:opacity-95">
              Report a lost item <ArrowRight className="h-4 w-4" />
            </Link>
            <Link to="/dashboard" className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-6 py-3 text-sm font-medium text-foreground transition hover:bg-accent">
              Browse found items
            </Link>
          </div>
        </div>

        <div className="relative mx-auto mt-16 max-w-5xl">
          <div className="overflow-hidden rounded-3xl border border-border bg-card shadow-[var(--shadow-elegant)]">
            <img
              src={heroImg}
              alt="Aerial view of a modern university campus"
              width={1600}
              height={1200}
              className="h-[420px] w-full object-cover"
            />
          </div>
          <div className="absolute -bottom-6 left-6 hidden w-72 rounded-2xl border border-border bg-card p-4 shadow-[var(--shadow-soft)] md:block">
            <div className="flex items-center gap-3">
              <span className="grid h-9 w-9 place-items-center rounded-lg bg-primary-soft text-primary">
                <CheckCircle2 className="h-5 w-5" />
              </span>
              <div>
                <p className="text-sm font-medium">Match found</p>
                <p className="text-xs text-muted-foreground">Blue water bottle • Library 2F</p>
              </div>
            </div>
          </div>
          <div className="absolute -top-6 right-6 hidden rounded-2xl border border-border bg-card px-4 py-3 shadow-[var(--shadow-soft)] md:block">
            <p className="text-xs text-muted-foreground">Items reunited this week</p>
            <p className="font-display text-2xl font-semibold">1,284</p>
          </div>
        </div>
      </div>
    </section>
  );
}

const features = [
  { icon: Sparkles, title: "AI image matching", desc: "Snap a photo. Our model matches it against reported items in seconds." },
  { icon: MapPin, title: "Location-aware", desc: "Pinpoint where items were lost or found across buildings, floors, and rooms." },
  { icon: Bell, title: "Real-time alerts", desc: "Get notified the moment your missing item is reported by someone else." },
  { icon: ShieldCheck, title: "Secure handoff", desc: "Verified pickup with one-time codes, so items only reach their owner." },
];

function Features() {
  return (
    <section id="features" className="mx-auto max-w-7xl px-6 py-24">
      <div className="max-w-2xl">
        <p className="text-sm font-medium text-primary">Built for campus life</p>
        <h2 className="mt-3 text-4xl font-semibold tracking-tight md:text-5xl">Everything you need to close the loop on lost items.</h2>
      </div>
      <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {features.map((f) => (
          <div key={f.title} className="group rounded-2xl border border-border bg-card p-6 transition hover:shadow-[var(--shadow-soft)]">
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-primary-soft text-primary transition group-hover:scale-105">
              <f.icon className="h-5 w-5" />
            </span>
            <h3 className="mt-5 text-lg font-semibold">{f.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

const steps = [
  { icon: Camera, title: "Snap & report", desc: "Found something? Take a photo and drop a pin. Lost something? Describe it." },
  { icon: Sparkles, title: "AI matches it", desc: "Our system pairs lost reports with found items using image and text signals." },
  { icon: MessageSquare, title: "Reunite securely", desc: "Owner verifies with a one-time code, then picks up at the campus hub." },
];

function HowItWorks() {
  return (
    <section id="how" className="border-y border-border bg-secondary/40 py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="flex items-end justify-between gap-6">
          <div>
            <p className="text-sm font-medium text-primary">How it works</p>
            <h2 className="mt-3 max-w-xl text-4xl font-semibold tracking-tight md:text-5xl">Three steps from lost to found.</h2>
          </div>
        </div>
        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {steps.map((s, i) => (
            <div key={s.title} className="relative rounded-2xl border border-border bg-card p-7">
              <span className="font-display text-sm text-muted-foreground">0{i + 1}</span>
              <span className="mt-4 grid h-11 w-11 place-items-center rounded-xl bg-primary text-primary-foreground">
                <s.icon className="h-5 w-5" />
              </span>
              <h3 className="mt-5 text-xl font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CampusStats() {
  const stats = [
    { v: "92%", l: "Match rate within 48 hours" },
    { v: "1.2M", l: "Items reunited platform-wide" },
    { v: "180+", l: "Campuses using FoundIt" },
    { v: "4.9", l: "Average student rating" },
  ];
  return (
    <section id="campus" className="mx-auto max-w-7xl px-6 py-24">
      <div className="overflow-hidden rounded-3xl bg-[var(--gradient-hero)] p-10 text-primary-foreground md:p-16">
        <div className="max-w-2xl">
          <h2 className="text-4xl font-semibold tracking-tight md:text-5xl">Trusted by campuses everywhere.</h2>
          <p className="mt-4 text-base text-primary-foreground/80">From dorms to lecture halls, FoundIt scales with your campus operations and integrates with existing security workflows.</p>
        </div>
        <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((s) => (
            <div key={s.l}>
              <p className="font-display text-4xl font-semibold md:text-5xl">{s.v}</p>
              <p className="mt-2 text-sm text-primary-foreground/80">{s.l}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section className="mx-auto max-w-7xl px-6 pb-24">
      <div className="rounded-3xl border border-border bg-card p-10 text-center md:p-16">
        <h2 className="mx-auto max-w-2xl text-4xl font-semibold tracking-tight md:text-5xl">Bring FoundIt to your campus.</h2>
        <p className="mx-auto mt-4 max-w-xl text-muted-foreground">Set up in under a day. Free pilot for the first semester.</p>
        <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <button className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground shadow-[var(--shadow-elegant)] transition hover:opacity-95">
            Request a demo <ArrowRight className="h-4 w-4" />
          </button>
          <button className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 text-sm font-medium text-foreground transition hover:bg-accent">
            Talk to sales
          </button>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 py-8 text-sm text-muted-foreground sm:flex-row">
        <div className="flex items-center gap-2">
          <span className="grid h-6 w-6 place-items-center rounded-md bg-primary text-primary-foreground">
            <Search className="h-3 w-3" strokeWidth={2.5} />
          </span>
          <span>© {new Date().getFullYear()} FoundIt. All rights reserved.</span>
        </div>
        <div className="flex gap-6">
          <a href="#" className="hover:text-foreground">Privacy</a>
          <a href="#" className="hover:text-foreground">Terms</a>
          <a href="#" className="hover:text-foreground">Contact</a>
        </div>
      </div>
    </footer>
  );
}

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Nav />
      <main>
        <Hero />
        <Features />
        <HowItWorks />
        <CampusStats />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}
