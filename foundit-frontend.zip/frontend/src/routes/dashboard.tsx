import { createFileRoute, Link, redirect, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Search, MapPin, Clock, Filter, Plus, Home, Compass, Bell, User, ArrowLeft, ArrowRight, Upload, Check, LogOut } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { listItems, createItem } from "@/lib/items.functions";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — FoundIt" },
      { name: "description", content: "Browse lost and found items reported across campus." },
    ],
  }),
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) {
      throw redirect({ to: "/auth" });
    }
    return { userEmail: data.user.email ?? "" };
  },
  component: DashboardPage,
});

type ItemStatus = "lost" | "found";
type Item = {
  id: string;
  title: string;
  status: ItemStatus;
  category: string;
  location: string;
  description: string | null;
  photo_url: string | null;
  created_at: string;
};

function relativeTime(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

function colorFor(id: string) {
  const hues = [240, 25, 220, 160, 300, 60, 200, 340];
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return `oklch(0.85 0.08 ${hues[h % hues.length]})`;
}

function DashboardPage() {
  const { userEmail } = Route.useRouteContext();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"all" | ItemStatus>("all");
  const [reportOpen, setReportOpen] = useState(false);

  const fetchItems = useServerFn(listItems);
  const { data: items = [] } = useQuery({
    queryKey: ["items"],
    queryFn: () => fetchItems(),
  });

  const signOut = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/" });
  };

  const initial = (userEmail?.[0] ?? "U").toUpperCase();

  const filtered = useMemo(() => {
    return (items as Item[]).filter((i) => {
      if (filter !== "all" && i.status !== filter) return false;
      const q = query.trim().toLowerCase();
      if (!q) return true;
      return (
        i.title.toLowerCase().includes(q) ||
        i.location.toLowerCase().includes(q) ||
        i.category.toLowerCase().includes(q)
      );
    });
  }, [query, filter, items]);

  const counts = {
    all: items.length,
    lost: (items as Item[]).filter((i) => i.status === "lost").length,
    found: (items as Item[]).filter((i) => i.status === "found").length,
  };

  return (
    <div className="min-h-screen bg-background pb-24 md:pb-0">
      {/* Top bar */}
      <header className="sticky top-0 z-30 border-b border-border bg-background/85 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 md:px-6">
          <Link to="/" className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-primary text-primary-foreground">
              <Search className="h-4 w-4" strokeWidth={2.5} />
            </span>
            <span className="font-display text-lg font-semibold tracking-tight">FoundIt</span>
          </Link>
          <div className="hidden items-center gap-3 md:flex">
            <Button variant="ghost" size="icon"><Bell className="h-5 w-5" /></Button>
            <div title={userEmail} className="grid h-9 w-9 place-items-center rounded-full bg-primary-soft text-primary text-sm font-semibold">{initial}</div>
            <Button variant="ghost" size="icon" onClick={signOut} aria-label="Sign out"><LogOut className="h-5 w-5" /></Button>
          </div>
          <Button onClick={() => setReportOpen(true)} className="hidden rounded-full md:inline-flex">
            <Plus className="h-4 w-4" /> Report an item
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8 md:px-6 md:py-10">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-semibold tracking-tight md:text-4xl">Campus items</h1>
          <p className="text-sm text-muted-foreground">Search through items reported lost or found around campus.</p>
        </div>

        {/* Search */}
        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by item, location, or category…"
              className="h-12 rounded-full border-border bg-card pl-10 text-sm"
            />
          </div>
          <Button variant="outline" className="h-12 rounded-full">
            <Filter className="h-4 w-4" /> Filters
          </Button>
        </div>

        {/* Status tabs */}
        <div className="mt-6 inline-flex rounded-full border border-border bg-card p-1">
          {(["all", "lost", "found"] as const).map((s) => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={
                "rounded-full px-4 py-2 text-sm font-medium capitalize transition " +
                (filter === s
                  ? "bg-primary text-primary-foreground shadow-[var(--shadow-soft)]"
                  : "text-muted-foreground hover:text-foreground")
              }
            >
              {s} <span className="ml-1 opacity-70">({counts[s]})</span>
            </button>
          ))}
        </div>

        {/* Cards */}
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((item) => (
            <ItemCard key={item.id} item={item} />
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="mt-12 rounded-2xl border border-dashed border-border bg-card p-12 text-center">
            <p className="text-sm text-muted-foreground">No items match your search.</p>
          </div>
        )}
      </main>

      {/* Mobile FAB */}
      <button
        onClick={() => setReportOpen(true)}
        className="fixed bottom-24 right-5 z-30 grid h-14 w-14 place-items-center rounded-full bg-primary text-primary-foreground shadow-[var(--shadow-elegant)] transition active:scale-95 md:hidden"
        aria-label="Report an item"
      >
        <Plus className="h-6 w-6" />
      </button>

      <BottomNav onReport={() => setReportOpen(true)} />

      <ReportItemDialog open={reportOpen} onOpenChange={setReportOpen} />
    </div>
  );
}

function ItemCard({ item }: { item: Item }) {
  const isLost = item.status === "lost";
  const bg = item.photo_url
    ? undefined
    : { background: `linear-gradient(135deg, ${colorFor(item.id)}, oklch(0.96 0.012 250))` };
  return (
    <article className="group overflow-hidden rounded-2xl border border-border bg-card transition hover:shadow-[var(--shadow-soft)]">
      <div className="relative aspect-[5/3] w-full overflow-hidden" style={bg}>
        {item.photo_url && (
          <img src={item.photo_url} alt={item.title} className="h-full w-full object-cover" />
        )}
        <div className="absolute left-3 top-3">
          <Badge
            className={
              "rounded-full border-0 px-2.5 py-1 text-[11px] font-medium uppercase tracking-wide " +
              (isLost
                ? "bg-destructive/10 text-destructive"
                : "bg-primary/10 text-primary")
            }
          >
            {item.status}
          </Badge>
        </div>
      </div>
      <div className="p-4">
        <h3 className="text-base font-semibold leading-snug">{item.title}</h3>
        <p className="mt-1 line-clamp-1 text-xs text-muted-foreground">{item.description ?? ""}</p>
        <div className="mt-3 flex items-center gap-3 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{item.location}</span>
          <span className="inline-flex items-center gap-1"><Clock className="h-3.5 w-3.5" />{relativeTime(item.created_at)}</span>
        </div>
      </div>
    </article>
  );
}

function BottomNav({ onReport }: { onReport: () => void }) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 border-t border-border bg-background/95 backdrop-blur-xl md:hidden">
      <div className="mx-auto grid max-w-md grid-cols-5 px-2 py-2">
        <NavBtn icon={Home} label="Home" active />
        <NavBtn icon={Compass} label="Browse" />
        <button onClick={onReport} className="mx-auto -mt-6 grid h-12 w-12 place-items-center rounded-full bg-primary text-primary-foreground shadow-[var(--shadow-elegant)]">
          <Plus className="h-5 w-5" />
        </button>
        <NavBtn icon={Bell} label="Alerts" />
        <NavBtn icon={User} label="Profile" />
      </div>
    </nav>
  );
}

function NavBtn({ icon: Icon, label, active }: { icon: React.ElementType; label: string; active?: boolean }) {
  return (
    <button className={"flex flex-col items-center gap-1 py-1 text-[11px] font-medium transition " + (active ? "text-primary" : "text-muted-foreground")}>
      <Icon className="h-5 w-5" />
      {label}
    </button>
  );
}

/* ---------------- Report Item Dialog ---------------- */

const CATEGORIES = ["Electronics", "Accessories", "Books", "Personal", "Jewelry", "Clothing", "Other"];

function ReportItemDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const [step, setStep] = useState(1);
  const [type, setType] = useState<ItemStatus>("found");
  const [photo, setPhoto] = useState<string | null>(null);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("");
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submitFn = useServerFn(createItem);
  const qc = useQueryClient();
  const mutation = useMutation({
    mutationFn: async () => {
      let photo_url = "";
      if (photoFile) {
        const { data: userData } = await supabase.auth.getUser();
        const uid = userData.user?.id;
        if (!uid) throw new Error("Not signed in");
        const ext = photoFile.name.split(".").pop()?.toLowerCase() ?? "jpg";
        if (!["jpg", "jpeg", "png", "webp"].includes(ext)) throw new Error("Unsupported image type");
        if (photoFile.size > 10 * 1024 * 1024) throw new Error("Image too large (max 10MB)");
        const path = `${uid}/${crypto.randomUUID()}.${ext}`;
        const { error: upErr } = await supabase.storage
          .from("item-photos")
          .upload(path, photoFile, { contentType: photoFile.type, upsert: false });
        if (upErr) throw new Error(upErr.message);
        const { data: signed } = await supabase.storage
          .from("item-photos")
          .createSignedUrl(path, 60 * 60 * 24 * 365);
        photo_url = signed?.signedUrl ?? "";
      }
      return submitFn({
        data: {
          title: title.trim(),
          description: description.trim(),
          category,
          location: location.trim(),
          status: type,
          photo_url,
        },
      });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["items"] });
      setSubmitted(true);
    },
    onError: (e: Error) => setError(e.message),
  });

  const reset = () => {
    setStep(1); setType("found"); setPhoto(null); setPhotoFile(null); setTitle(""); setCategory(""); setLocation(""); setDescription(""); setSubmitted(false); setError(null);
  };

  const handleClose = (o: boolean) => {
    onOpenChange(o);
    if (!o) setTimeout(reset, 200);
  };

  const handlePhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) { setError("Image too large (max 10MB)"); return; }
      setPhotoFile(file);
      setPhoto(URL.createObjectURL(file));
      setError(null);
    }
  };

  const canNext =
    (step === 1 && title.trim().length >= 2) ||
    (step === 2 && !!category) ||
    (step === 3 && location.trim().length > 0) ||
    step === 4;

  const submit = () => { setError(null); mutation.mutate(); };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-lg overflow-hidden p-0">
        {submitted ? (
          <div className="px-6 py-10 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-primary-soft text-primary">
              <Check className="h-6 w-6" />
            </div>
            <h3 className="mt-4 text-xl font-semibold">Report submitted</h3>
            <p className="mt-2 text-sm text-muted-foreground">We'll alert you if there's a match.</p>
            <Button className="mt-6 rounded-full" onClick={() => handleClose(false)}>Done</Button>
          </div>
        ) : (
          <>
            <DialogHeader className="border-b border-border px-6 py-5">
              <DialogTitle>Report an item</DialogTitle>
              <DialogDescription>Step {step} of 4</DialogDescription>
              <div className="mt-3 flex gap-1.5">
                {[1, 2, 3, 4].map((n) => (
                  <div key={n} className={"h-1 flex-1 rounded-full " + (n <= step ? "bg-primary" : "bg-muted")} />
                ))}
              </div>
            </DialogHeader>

            <div className="px-6 py-6">
              {step === 1 && (
                <div className="space-y-5">
                  <div>
                    <Label className="text-xs uppercase tracking-wide text-muted-foreground">Item status</Label>
                    <div className="mt-2 grid grid-cols-2 gap-2">
                      {(["found", "lost"] as const).map((t) => (
                        <button
                          key={t}
                          onClick={() => setType(t)}
                          className={
                            "rounded-xl border-2 px-4 py-3 text-sm font-medium capitalize transition " +
                            (type === t ? "border-primary bg-primary-soft text-primary" : "border-border text-muted-foreground hover:border-primary/40")
                          }
                        >
                          I {t === "found" ? "found" : "lost"} something
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="item-title" className="text-xs uppercase tracking-wide text-muted-foreground">Title</Label>
                    <Input id="item-title" value={title} onChange={(e) => setTitle(e.target.value.slice(0, 120))} placeholder="e.g. Blue water bottle" className="mt-2 h-12" maxLength={120} />
                  </div>
                  <div>
                    <Label className="text-xs uppercase tracking-wide text-muted-foreground">Photo (optional)</Label>
                    <label className="mt-2 flex aspect-[5/3] cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-border bg-secondary/40 transition hover:border-primary/50 overflow-hidden">
                      {photo ? (
                        <img src={photo} alt="upload preview" className="h-full w-full object-cover" />
                      ) : (
                        <div className="text-center">
                          <Upload className="mx-auto h-6 w-6 text-muted-foreground" />
                          <p className="mt-2 text-sm font-medium">Tap to upload a photo</p>
                          <p className="text-xs text-muted-foreground">PNG or JPG up to 10MB</p>
                        </div>
                      )}
                      <input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={handlePhoto} />
                    </label>
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-3">
                  <Label>Category</Label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger className="h-12">
                      <SelectValue placeholder="Choose a category" />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map((c) => (
                        <SelectItem key={c} value={c}>{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">Helps us match your report faster.</p>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-3">
                  <Label>Location</Label>
                  <Input
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="e.g. Library, 2nd floor"
                    className="h-12"
                  />
                  <p className="text-xs text-muted-foreground">Where was the item last seen?</p>
                </div>
              )}

              {step === 4 && (
                <div className="space-y-3">
                  <Label>Description</Label>
                  <Textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value.slice(0, 2000))}
                    placeholder="Any details that would help identify the item…"
                    rows={5}
                    maxLength={2000}
                  />
                  {error && <p className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>}
                </div>
              )}
            </div>

            <div className="flex items-center justify-between border-t border-border px-6 py-4">
              <Button
                variant="ghost"
                onClick={() => setStep((s) => Math.max(1, s - 1))}
                disabled={step === 1}
              >
                <ArrowLeft className="h-4 w-4" /> Back
              </Button>
              {step < 4 ? (
                <Button
                  className="rounded-full"
                  disabled={!canNext}
                  onClick={() => setStep((s) => Math.min(4, s + 1))}
                >
                  Continue <ArrowRight className="h-4 w-4" />
                </Button>
              ) : (
                <Button className="rounded-full" onClick={submit} disabled={mutation.isPending}>
                  Submit report <Check className="h-4 w-4" />
                </Button>
              )}
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}